(() => {
var exports = {};
exports.id = 931;
exports.ids = [931];
exports.modules = {

/***/ 8038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 8704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 7897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 6786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 5868:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/app-render");

/***/ }),

/***/ 1844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 6624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 5281:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/route-modules/route-module");

/***/ }),

/***/ 7085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 1830:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/get-img-props");

/***/ }),

/***/ 199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 6864:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head");

/***/ }),

/***/ 9569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 2210:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config");

/***/ }),

/***/ 5359:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context");

/***/ }),

/***/ 7160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 7887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 8735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 8231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 4614:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix");

/***/ }),

/***/ 3750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 9618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 8658:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once");

/***/ }),

/***/ 9491:
/***/ ((module) => {

"use strict";
module.exports = require("assert");

/***/ }),

/***/ 2361:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 7147:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 3685:
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ 5687:
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ 2037:
/***/ ((module) => {

"use strict";
module.exports = require("os");

/***/ }),

/***/ 1017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 2781:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 6224:
/***/ ((module) => {

"use strict";
module.exports = require("tty");

/***/ }),

/***/ 7310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 3837:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 9796:
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ 5047:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   routeModule: () => (/* binding */ routeModule),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7262);
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9513);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1823);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2502);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);
// @ts-ignore this need to be imported from next/dist to be external


const AppPageRouteModule = next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__.AppPageRouteModule;
// We inject the tree and pages here so that we can use them in the route
// module.
const tree = {
        children: [
        '',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 2872)), "D:\\MOWA\\landing-uct\\src\\app\\page.js"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 3881))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }]
      },
        {
        'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 2911)), "D:\\MOWA\\landing-uct\\src\\app\\layout.js"],
'not-found': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 5493, 23)), "next/dist/client/components/not-found-error"],
        metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 3881))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
      }
      ]
      }.children;
const pages = ["D:\\MOWA\\landing-uct\\src\\app\\page.js"];

// @ts-expect-error - replaced by webpack/turbopack loader

const __next_app_require__ = __webpack_require__
const __next_app_load_chunk__ = () => Promise.resolve()
const originalPathname = "/page";
const __next_app__ = {
    require: __next_app_require__,
    loadChunk: __next_app_load_chunk__
};

// Create and export the route module that will be consumed.
const routeModule = new AppPageRouteModule({
    definition: {
        kind: next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.APP_PAGE,
        page: "/page",
        pathname: "/",
        // The following aren't used in production.
        bundlePath: "",
        filename: "",
        appPaths: []
    },
    userland: {
        loaderTree: tree
    }
});

//# sourceMappingURL=app-page.js.map

/***/ }),

/***/ 6253:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 2987, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 831, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 6926, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 4282, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 6505, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 1232, 23))

/***/ }),

/***/ 1254:
/***/ (() => {



/***/ }),

/***/ 3572:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 7264));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 3380, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 5177))

/***/ }),

/***/ 5177:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ components_Form)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(8038);
var react_default = /*#__PURE__*/__webpack_require__.n(react_);
// EXTERNAL MODULE: ./node_modules/react-hook-form/dist/index.esm.mjs
var index_esm = __webpack_require__(6558);
;// CONCATENATED MODULE: ./src/components/Connector.jsx


const Connector = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "flex items-center justify-center",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "flex flex-col md:flex-row justify-around w-11/12 md:w-6/12  items-center absolute mx-auto bg-c-purple rounded-3xl text-white p-5",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "text-center md:block hidden",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                        className: "text-lg font-semibold",
                        children: [
                            "\xdanete al proceso de admisi\xf3n ",
                            /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                            "2023-II"
                        ]
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "flex items-center justify-center text-left",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: "text-6xl font-extrabold mx-5",
                            children: "26"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                className: "uppercase",
                                children: [
                                    "Examen ",
                                    /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                    "de admisi\xf3n ",
                                    /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "text-3xl font-extrabold",
                                        children: "Agosto"
                                    })
                                ]
                            })
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const components_Connector = (Connector);

// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(2451);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/react-hot-toast/dist/index.mjs + 1 modules
var dist = __webpack_require__(345);
// EXTERNAL MODULE: ./node_modules/axios/lib/axios.js + 46 modules
var axios = __webpack_require__(3258);
// EXTERNAL MODULE: ./node_modules/react-intersection-observer/index.mjs
var react_intersection_observer = __webpack_require__(3503);
// EXTERNAL MODULE: ./node_modules/framer-motion/dist/es/render/dom/motion.mjs + 113 modules
var motion = __webpack_require__(6861);
// EXTERNAL MODULE: ./node_modules/framer-motion/dist/es/animation/hooks/use-animation.mjs + 1 modules
var use_animation = __webpack_require__(8255);
;// CONCATENATED MODULE: ./src/components/Form.jsx
/* __next_internal_client_entry_do_not_use__ default auto */ 








const AnimatedInput = /*#__PURE__*/ react_default().forwardRef(({ controls, type, placeholder, registerProps, delay }, ref)=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion */.E.input, {
        ref: ref,
        initial: "hidden",
        animate: controls,
        required: true,
        variants: {
            visible: {
                opacity: 1,
                scale: 1,
                transition: {
                    duration: 1,
                    delay
                }
            },
            hidden: {
                opacity: 0,
                scale: 1
            }
        },
        type: type,
        className: "h-10 px-4 rounded-lg",
        placeholder: placeholder,
        ...registerProps
    });
});
AnimatedInput.displayName = "AnimatedInput";
const AnimatedSelect = /*#__PURE__*/ react_default().forwardRef(({ controls, children, delay }, ref)=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion */.E.select, {
        className: "h-10 px-4 rounded-lg w-full bg-white text-c-gray text-sm",
        ref: ref,
        initial: "hidden",
        animate: controls,
        required: true,
        defaultValue: "0",
        variants: {
            visible: {
                opacity: 1,
                scale: 1,
                transition: {
                    duration: 1,
                    delay
                }
            },
            hidden: {
                opacity: 0,
                scale: 1
            }
        },
        children: children
    });
});
AnimatedSelect.displayName = "AnimatedSelect";
const Form = ()=>{
    const [masters, setMasters] = (0,react_.useState)(null);
    const { register, handleSubmit, reset } = (0,index_esm/* useForm */.cI)();
    const [ref, inView] = (0,react_intersection_observer/* useInView */.YD)();
    const controls = (0,use_animation/* useAnimation */._)();
    (0,react_.useEffect)(()=>{
        const getMasterList = async ()=>{
            const response = await fetch("/api/masters");
            const data = await response.json();
            return data.data;
        };
        const fetchData = async ()=>{
            try {
                const mastersData = await getMasterList();
                setMasters(mastersData);
            } catch (error) {
                console.error("Error fetching data:", error);
            }
        };
        fetchData();
    }, []);
    (0,react_.useEffect)(()=>{
        if (inView) {
            controls.start("visible");
        }
    }, [
        controls,
        inView
    ]);
    const onSubmit = async (data)=>{
        console.log(data);
        dist/* default */.ZP.promise(axios/* default */.Z.post("/api/register", data), {
            loading: "Registrando...",
            success: ({ data })=>{
                return `${data.message}`;
            },
            error: "Ha ocurrido algo inesperado"
        });
        reset();
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "w-full h-full relative bg-c-blue-sky",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(dist/* Toaster */.x7, {
                position: "top-right"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(components_Connector, {}),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex h-[75vh] mt-10 items-center justify-center w-full mx-auto",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion */.E.div, {
                        variants: {
                            visible: {
                                opacity: 1,
                                scale: 1,
                                transition: {
                                    duration: 1,
                                    delay: 0
                                }
                            },
                            hidden: {
                                opacity: 0,
                                scale: 0.8
                            }
                        },
                        ref: ref,
                        animate: controls,
                        initial: "hidden",
                        className: "md:w-3/12 md:block hidden",
                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            src: "/form.png",
                            width: 500,
                            height: 130,
                            alt: "uct_logo"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "md:w-4/12 w-11/12",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
                            onSubmit: handleSubmit(onSubmit),
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion */.E.p, {
                                    variants: {
                                        visible: {
                                            opacity: 1,
                                            scale: 1,
                                            transition: {
                                                duration: 1,
                                                delay: 0.2
                                            }
                                        },
                                        hidden: {
                                            opacity: 0,
                                            scale: 1
                                        }
                                    },
                                    ref: ref,
                                    animate: controls,
                                    initial: "hidden",
                                    className: "text-center font-semibold text-c-black",
                                    children: "\xa1Completa el formulario y comienza tu transformaci\xf3n hoy!"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "grid w-full grid-cols-2 my-10 gap-x-5 gap-y-10 auto-rows-auto text-c-gray text-sm",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx(AnimatedInput, {
                                            ref: ref,
                                            delay: 0.2,
                                            controls: controls,
                                            type: "text",
                                            placeholder: "Nombres",
                                            ...register("name", {
                                                required: true
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(AnimatedInput, {
                                            ref: ref,
                                            delay: 0.3,
                                            controls: controls,
                                            type: "text",
                                            pattern: "^[0-9]+[0-9]*$",
                                            maxLength: "8",
                                            placeholder: "DNI",
                                            ...register("dni", {
                                                required: true,
                                                maxLength: 8
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(AnimatedInput, {
                                            ref: ref,
                                            delay: 0.4,
                                            controls: controls,
                                            type: "text",
                                            placeholder: "Apellido Materno",
                                            ...register("surname", {
                                                required: true
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(AnimatedInput, {
                                            ref: ref,
                                            delay: 0.5,
                                            controls: controls,
                                            type: "text",
                                            placeholder: "Apellido Paterno",
                                            ...register("lastname", {
                                                required: true
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(AnimatedInput, {
                                            ref: ref,
                                            delay: 0.6,
                                            controls: controls,
                                            type: "text",
                                            placeholder: "Correo Electr\xf3nico",
                                            ...register("email", {
                                                required: true
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(AnimatedInput, {
                                            ref: ref,
                                            delay: 0.7,
                                            controls: controls,
                                            type: "tel",
                                            pattern: "^[0-9]+[0-9]*$",
                                            maxLength: "9",
                                            placeholder: "Celular",
                                            ...register("phone", {
                                                required: true
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(AnimatedSelect, {
                                    ref: ref,
                                    delay: 0.8,
                                    controls: controls,
                                    ...register("masterDegree", {
                                        required: true
                                    }),
                                    placeholder: "Celular",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                            value: "0",
                                            disabled: true,
                                            children: "Seleccione un programa"
                                        }),
                                        masters ? /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
                                            children: masters.map((el)=>/*#__PURE__*/ jsx_runtime_.jsx("option", {
                                                    value: el.id,
                                                    children: el.name
                                                }, crypto.randomUUID()))
                                        }) : null
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "text-center md:text-left",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion */.E.button, {
                                        variants: {
                                            visible: {
                                                opacity: 1,
                                                scale: 1,
                                                transition: {
                                                    duration: 1,
                                                    delay: 0.9
                                                }
                                            },
                                            hidden: {
                                                opacity: 0,
                                                scale: 1
                                            }
                                        },
                                        ref: ref,
                                        animate: controls,
                                        initial: "hidden",
                                        type: "submit",
                                        className: "mt-8 px-14  bg-c-purple text-white py-1 rounded-lg shadow-md",
                                        children: "Enviar"
                                    })
                                })
                            ]
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const components_Form = (Form);


/***/ }),

/***/ 7264:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2451);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_intersection_observer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3503);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8255);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6861);
/* __next_internal_client_entry_do_not_use__ default auto */ 




const Hero = ()=>{
    const [ref, inView] = (0,react_intersection_observer__WEBPACK_IMPORTED_MODULE_3__/* .useInView */ .YD)();
    const controls = (0,framer_motion__WEBPACK_IMPORTED_MODULE_4__/* .useAnimation */ ._)();
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (inView) {
            controls.start("visible");
        }
    }, [
        controls,
        inView
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "h-[75%] w-11/12 md:w-7/12 items-center mx-auto flex md:flex-row flex-col justify-center md:justify-between",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_5__/* .motion */ .E.div, {
                variants: {
                    visible: {
                        opacity: 1,
                        scale: 1,
                        transition: {
                            duration: 1,
                            delay: 0
                        }
                    },
                    hidden: {
                        opacity: 0,
                        scale: 0.8
                    }
                },
                ref: ref,
                animate: controls,
                initial: "hidden",
                className: "text-center md:text-left",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                        className: "text-[2.5rem] md:text-6xl text-c-purple uppercase font-extrabold mt-20 md:mb-6 ",
                        children: "\xa1Estudia "
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                        className: "text-[2.5rem] md:text-6xl text-c-purple uppercase font-extrabold mb-10 ",
                        children: "tu posgrado!"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                        className: "text-c-yellow text-4xl font-extrabold",
                        children: "15 Maestr\xedas"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        className: "italic py-4 text-c-purple font-bold",
                        children: "\xa1Aprovecha esta oportunidad \xfanica!"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                        className: "bg-c-green rounded-md px-4 py-2 text-white text-sm shadow-md",
                        children: "Chatea con un experto"
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_5__/* .motion */ .E.div, {
                variants: {
                    visible: {
                        opacity: 1,
                        scale: 1,
                        transition: {
                            duration: 1,
                            delay: 0.3
                        }
                    },
                    hidden: {
                        opacity: 0,
                        scale: 0.5
                    }
                },
                ref: ref,
                animate: controls,
                initial: "hidden",
                className: "relative p-8",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "absolute md:right-10 right-5 md:top-5 top_10 text-xs md:text-sm text-c-purple",
                        children: "*1 a\xf1o de estudio "
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                        src: "/hero.png",
                        width: 500,
                        height: 130,
                        alt: "uct_logo"
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Hero);


/***/ }),

/***/ 2911:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ RootLayout),
/* harmony export */   metadata: () => (/* binding */ metadata)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _globals_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5023);
/* harmony import */ var _globals_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_globals_css__WEBPACK_IMPORTED_MODULE_1__);


const metadata = {
    title: "UCT - Posgrado",
    description: "Conoce nuestros programas de posgrado"
};
function RootLayout({ children }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("html", {
        lang: "es",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("body", {
            children: children
        })
    });
}


/***/ }),

/***/ 2872:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Home)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/react.shared-subset.js
var react_shared_subset = __webpack_require__(2947);
;// CONCATENATED MODULE: ./src/components/Footer.jsx


const Footer = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("nav", {
        className: "w-full py-5 h-[11%] md:h-[10%] bg-c-purple",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "w-11/12  h-full mx-auto text-white",
            children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                className: "text-center text-sm",
                children: "\xa9 Copyright 2023 Universidad Cat\xf3lica De Trujillo"
            })
        })
    });
};
/* harmony default export */ const components_Footer = (Footer);

// EXTERNAL MODULE: ./node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js
var module_proxy = __webpack_require__(1363);
;// CONCATENATED MODULE: ./src/components/Form.jsx

const proxy = (0,module_proxy.createProxy)(String.raw`D:\MOWA\landing-uct\src\components\Form.jsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const Form = (__default__);
;// CONCATENATED MODULE: ./src/components/Hero.jsx

const Hero_proxy = (0,module_proxy.createProxy)(String.raw`D:\MOWA\landing-uct\src\components\Hero.jsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: Hero_esModule, $$typeof: Hero_$$typeof } = Hero_proxy;
const Hero_default_ = Hero_proxy.default;


/* harmony default export */ const Hero = (Hero_default_);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(4178);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./src/components/Navbar.jsx



const Navbar = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("nav", {
        className: "w-full py-5 h-[11%] md:h-[10%] bg-c-purple",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "w-11/12 md:w-7/12 h-full flex justify-between mx-auto text-white",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                    src: "/uct_logo.png",
                    width: 130,
                    height: 130,
                    alt: "uct_logo"
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "flex justify-center items-center gap-32",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "italic hidden md:inline font-semibold",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: "text-c-yellow",
                                    children: "Tu \xe9xito"
                                }),
                                " empieza aqu\xed"
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            src: "/sunedu.png",
                            width: 130,
                            height: 130,
                            alt: "uct_logo"
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const components_Navbar = (Navbar);

;// CONCATENATED MODULE: ./src/app/page.js





function Home() {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("main", {
        className: "w-full min-h-screen h-screen",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "h-screen",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(components_Navbar, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(Hero, {})
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(Form, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(components_Footer, {})
                ]
            })
        ]
    });
}


/***/ }),

/***/ 3881:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85);
/* harmony import */ var next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__);
  

  /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((props) => {
    const imageData = {"type":"image/x-icon","sizes":"2501x2501"}
    const imageUrl = (0,next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__.fillMetadataSegment)(".", props.params, "favicon.ico")

    return [{
      ...imageData,
      url: imageUrl + "",
    }]
  });

/***/ }),

/***/ 5023:
/***/ (() => {



/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [587,879], () => (__webpack_exec__(5047)));
module.exports = __webpack_exports__;

})();